package com.Connectionsexample;

	import java.sql.Connection;
	import java.sql.PreparedStatement;
	import java.sql.ResultSet;
	import java.sql.SQLException;
	import java.sql.Statement;
	import java.util.ArrayList;
	import java.util.List;

	import com.Connectionsexample.Userbean;
	import com.Connectionsexample.ConnectionProvider;

	public class UserDao {

	    private Connection conn;

	    public UserDao() {
	    	conn = ConnectionProvider.getConnection();
	    }

	    public void addUser(Userbean userBean) {
	        try {
	        	String sql = "INSERT INTO Book(bookid, bookname)" +
	    		" VALUES (?, ?)";
	            PreparedStatement ps = conn.prepareStatement(sql);
	            
	            ps.setInt(1, userBean.getBookid());
	            ps.setString(2, userBean.getBookname());          
	            ps.executeUpdate();

	        } catch (SQLException e) {
	            e.printStackTrace();
	        }
	    }


}
